# Lunacid-FR installer / restorer. MIT license: see LICENCE-SCRIPTS.txt.
# Uses only Windows PowerShell 5.1 and .NET supplied with Windows.
[CmdletBinding()]
param(
    [ValidateSet('Install','Restore')][string]$Mode = 'Install',
    [string]$GameRoot = (Split-Path -Parent $PSScriptRoot)
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$lockStream = $null
$work = $null
$cleanup = $false
$exitCode = 1

function Digest([string]$File) {
    if (-not [IO.File]::Exists($File)) { throw "Fichier manquant : $File" }
    $stream=$null; $sha=[Security.Cryptography.SHA256]::Create()
    try {
        $stream=[IO.File]::Open($File,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()
    } finally { if ($stream) { $stream.Dispose() }; $sha.Dispose() }
}
function Under-Root([string]$Relative) {
    $full = [IO.Path]::GetFullPath((Join-Path $script:root $Relative))
    if (-not $full.StartsWith($script:root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Chemin en dehors du dossier du jeu.' }
    # Refuse junctions/symlinks under the selected game folder.
    $cursor = $full
    while ($cursor -and $cursor.Length -gt $script:root.Length) {
        if (Test-Path -LiteralPath $cursor) {
            if (((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Lien symbolique non pris en charge dans les chemins du patch.' }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
    }
    return $full
}
function Game-Closed {
    if (@(Get-Process -Name LUNACID -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Fermez Lunacid, puis relancez ce fichier BAT.' }
}
function Equal-Hash([string]$File,[string]$Expected,[string]$Message) {
    if ((Digest $File) -ne $Expected) { throw $Message }
}
function Apply-Delta([string]$Patch,[string]$Source,[string]$Output,$Entry) {
    Equal-Hash $Patch $Entry.patchSha256 'Patch endommage : telechargez et extrayez a nouveau le ZIP.'
    Equal-Hash $Source $Entry.sourceSha256 'La source anglaise du patch est incompatible ou endommagee.'
    $reader=$null; $sourceStream=$null; $outputStream=$null
    try {
        $reader = New-Object IO.BinaryReader([IO.File]::Open($Patch,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read))
        if ([Text.Encoding]::ASCII.GetString($reader.ReadBytes(8)) -ne 'LFDP0001') { throw 'Format du patch inconnu.' }
        $sourceSize=$reader.ReadInt64(); $targetSize=$reader.ReadInt64()
        $sourceHash=([BitConverter]::ToString($reader.ReadBytes(32))).Replace('-','').ToLowerInvariant()
        $targetHash=([BitConverter]::ToString($reader.ReadBytes(32))).Replace('-','').ToLowerInvariant()
        $count=$reader.ReadUInt32()
        if ($sourceSize -ne $Entry.sourceBytes -or $targetSize -ne $Entry.targetBytes -or $sourceHash -ne $Entry.sourceSha256 -or $targetHash -ne $Entry.targetSha256 -or $count -gt 100000 -or $targetSize -gt 100MB) { throw 'En-tete du patch invalide.' }
        $sourceStream=[IO.File]::Open($Source,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
        if ($sourceStream.Length -ne $sourceSize) { throw 'Taille de la source incorrecte.' }
        $outputStream=[IO.File]::Open($Output,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $buffer=New-Object byte[] 262144
        for ($i=0; $i -lt $count; $i++) {
            $op=$reader.ReadByte()
            if ($op -eq 0) {
                $offset=$reader.ReadInt64(); $length=$reader.ReadUInt32()
                if ($offset -lt 0 -or $offset -gt $sourceSize -or $length -gt ($sourceSize-$offset) -or $length -gt ($targetSize-$outputStream.Position)) { throw 'Reference binaire hors limites.' }
                $sourceStream.Position=$offset; [long]$remaining=$length
                while ($remaining -gt 0) {
                    $read=$sourceStream.Read($buffer,0,[int][Math]::Min($buffer.Length,$remaining))
                    if ($read -eq 0) { throw 'Source binaire tronquee.' }
                    $outputStream.Write($buffer,0,$read); $remaining-=$read
                }
            } elseif ($op -eq 1) {
                $length=$reader.ReadUInt32()
                if ($length -gt ($reader.BaseStream.Length-$reader.BaseStream.Position) -or $length -gt ($targetSize-$outputStream.Position)) { throw 'Ajout binaire hors limites.' }
                [long]$remaining=$length
                while ($remaining -gt 0) {
                    $read=$reader.Read($buffer,0,[int][Math]::Min($buffer.Length,$remaining))
                    if ($read -eq 0) { throw 'Patch tronque.' }
                    $outputStream.Write($buffer,0,$read); $remaining-=$read
                }
            } else { throw 'Instruction binaire inconnue.' }
        }
        if ($reader.BaseStream.Position -ne $reader.BaseStream.Length -or $outputStream.Length -ne $targetSize) { throw 'Fin du patch incorrecte.' }
        $outputStream.Flush($true)
    } finally {
        if ($outputStream) { $outputStream.Dispose() }
        if ($sourceStream) { $sourceStream.Dispose() }
        if ($reader) { $reader.Dispose() }
    }
    Equal-Hash $Output $Entry.targetSha256 'Le fichier reconstruit est incorrect. Le jeu reste inchange.'
}

try {
    Write-Host 'LUNACID - Traduction francaise 1.0-BETA'
    if ($PSVersionTable.PSVersion.Major -lt 5) { throw 'Windows PowerShell 5.1 ou plus recent est requis (inclus dans Windows 10/11).' }
    $script:root=[IO.Path]::GetFullPath($GameRoot).TrimEnd('\','/')
    if (-not [IO.File]::Exists((Under-Root 'LUNACID.exe'))) { throw 'Jeu introuvable. Extrayez tout le ZIP dans le dossier contenant LUNACID.exe, puis relancez le BAT.' }
    $package = Under-Root 'Patch-FR'
    if ([IO.Path]::GetFullPath($PSScriptRoot) -ne $package) { throw 'Le dossier Patch-FR doit etre place a cote de LUNACID.exe.' }
    Game-Closed
    try { $lockStream=[IO.File]::Open((Under-Root 'Patch-FR\operation.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
    catch { throw 'Operation deja en cours, ou dossier non accessible en ecriture. Fermez les autres installateurs et verifiez les droits du dossier.' }
    $manifest=Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.format -ne 'LFDP0001' -or $manifest.release -ne '1.0-BETA' -or $manifest.gameVersion -ne '2.2.0' -or @($manifest.files).Count -ne 2) { throw 'Manifeste du patch incompatible.' }
    if ($manifest.versionFile -ne 'LUNACID_Data/globalgamemanagers') { throw 'Chemin de version incorrect.' }
    Equal-Hash (Under-Root $manifest.versionFile) $manifest.versionSha256 'Version du jeu incompatible. Ce patch accepte uniquement les fichiers verifies de Lunacid 2.2.0 pour Windows. Aucun fichier du jeu n''a ete remplace.'
    $expectedPaths=@('LUNACID_Data/resources.assets','LUNACID_Data/Resources/TXT/ENG/COMM.txt')
    $expectedIds=@('resources','comm')
    $entries=@()
    for ($i=0; $i -lt 2; $i++) {
        $entry=$manifest.files[$i]
        if ($entry.id -ne $expectedIds[$i] -or $entry.relativePath -ne $expectedPaths[$i] -or $entry.patch -ne ($expectedIds[$i]+'.lfdelta')) { throw 'Manifeste : fichier non autorise.' }
        $target=Under-Root $entry.relativePath
        $current=Digest $target
        if ($current -ne $entry.sourceSha256 -and $current -ne $entry.targetSha256) { throw "Fichier incompatible ou modifie par un autre mod : $($entry.relativePath). Rien n'a ete remplace. Restaurez vos originaux compatibles ou verifiez les fichiers avec Steam." }
        $backup=Under-Root ('Lunacid-FR-Sauvegardes\v1.0-BETA\'+$entry.id+'.original')
        $entries+= [PSCustomObject]@{spec=$entry;target=$target;before=$current;backup=$backup;patch=(Join-Path $package $entry.patch);temp=$null;rollback=$null}
    }
    $allEnglish=@($entries | Where-Object { $_.before -ne $_.spec.sourceSha256 }).Count -eq 0
    $allFrench=@($entries | Where-Object { $_.before -ne $_.spec.targetSha256 }).Count -eq 0
    if ($Mode -eq 'Restore' -and $allEnglish) {
        Write-Host 'Les fichiers anglais sont deja en place. Aucune modification.' -ForegroundColor Green
        $exitCode=0
    } else {
        # Verify every existing backup and every patch BEFORE backing up or replacing anything.
        foreach ($e in $entries) {
            if ([IO.File]::Exists($e.backup)) {
                Equal-Hash $e.backup $e.spec.sourceSha256 'Sauvegarde anglaise endommagee ou incompatible. Elle ne sera pas ecrasee.'
            } elseif ($Mode -eq 'Restore' -or $e.before -eq $e.spec.targetSha256) {
                throw 'Sauvegarde anglaise absente. Pour cette copie deja traduite, restaurez les fichiers originaux avec Steam avant d''installer ce kit. Aucun fichier remplace.'
            }
            if ($Mode -eq 'Install') { Equal-Hash $e.patch $e.spec.patchSha256 'Patch endommage. Telechargez et extrayez de nouveau le ZIP.' }
        }
        if ($Mode -eq 'Install' -and $allFrench) {
            Write-Host 'La traduction francaise 1.0-BETA est deja installee et ses sauvegardes sont valides. Aucune modification.' -ForegroundColor Green
            $exitCode=0
        } else {
            foreach ($e in $entries) {
                if (-not [IO.File]::Exists($e.backup)) {
                    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($e.backup)) | Out-Null
                    Equal-Hash $e.target $e.before 'Un fichier a change pendant le controle. Operation annulee.'
                    [IO.File]::Copy($e.target,$e.backup,$false)
                    Equal-Hash $e.backup $e.spec.sourceSha256 'Erreur de sauvegarde. Aucun remplacement effectue.'
                }
            }
            $work=Under-Root ('Patch-FR\travail-'+[Guid]::NewGuid().ToString('N'))
            [IO.Directory]::CreateDirectory($work) | Out-Null
            $cleanup=$true
            foreach ($e in $entries) {
                $e.temp=Join-Path $work ($e.spec.id+'.nouveau')
                $e.rollback=Join-Path $work ($e.spec.id+'.precedent')
                if ($Mode -eq 'Install') {
                    Apply-Delta $e.patch $e.backup $e.temp $e.spec
                } else {
                    [IO.File]::Copy($e.backup,$e.temp,$false)
                    Equal-Hash $e.temp $e.spec.sourceSha256 'Restauration preparee incorrecte.'
                }
            }
            # Both candidates exist and are verified. Keep per-file rollback copies.
            $committed=New-Object 'System.Collections.Generic.List[object]'
            try {
                Game-Closed
                foreach ($e in $entries) { Equal-Hash $e.target $e.before 'Un fichier a change avant installation. Operation annulee.' }
                foreach ($e in $entries) {
                    Equal-Hash $e.target $e.before 'Un fichier a change pendant installation.'
                    [IO.File]::Replace($e.temp,$e.target,$e.rollback)
                    $committed.Add($e)
                    $expected=if($Mode -eq 'Install'){$e.spec.targetSha256}else{$e.spec.sourceSha256}
                    Equal-Hash $e.target $expected 'Controle apres remplacement incorrect.'
                }
            } catch {
                $problem=$_.Exception.Message
                for ($n=$committed.Count-1; $n -ge 0; $n--) {
                    $e=$committed[$n]
                    try {
                        # Windows PowerShell 5.1 converts a null string argument to
                        # an empty backup path; use an explicit temporary filename.
                        [IO.File]::Replace($e.rollback,$e.target,(Join-Path $work ($e.spec.id+'.annule')))
                        Equal-Hash $e.target $e.before 'Retour a la version precedente incorrect.'
                    } catch { $cleanup=$false }
                }
                if (-not $cleanup) { throw "Echec du retour automatique. Vos originaux restent dans Lunacid-FR-Sauvegardes ; fichiers de secours conserves dans $work. Detail : $problem" }
                throw "Operation annulee ; les fichiers du jeu ont ete remis dans leur etat precedent. Detail : $problem"
            }
            if ($Mode -eq 'Install') {
                Write-Host 'SUCCES : traduction francaise installee et verifiee. Lancez Lunacid et gardez la langue English.' -ForegroundColor Green
            } else {
                Write-Host 'SUCCES : fichiers anglais originaux restaures et verifies. Les sauvegardes anglaises sont conservees.' -ForegroundColor Green
            }
            $exitCode=0
        }
    }
} catch {
    Write-Host ''
    Write-Host ('ERREUR : '+$_.Exception.Message) -ForegroundColor Red
    Write-Host 'Aucune sauvegarde de progression n''est modifiee par ce kit.'
    $exitCode=1
} finally {
    if ($work -and $cleanup) {
        # Only this operation's freshly created flat directory is removed.
        try {
            $checked=Under-Root ('Patch-FR\'+[IO.Path]::GetFileName($work))
            if ($checked -ne $work) { throw 'Chemin temporaire inattendu.' }
            foreach ($f in [IO.Directory]::GetFiles($work)) { Remove-Item -LiteralPath $f -Force }
            [IO.Directory]::Delete($work,$false)
        } catch { Write-Host 'Les fichiers temporaires ont ete conserves. Les originaux restent sauvegardes.' }
    }
    if ($lockStream) { $lockStream.Dispose() }
}
exit $exitCode
