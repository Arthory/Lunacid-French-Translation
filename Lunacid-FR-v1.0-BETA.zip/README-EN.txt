LUNACID — UNOFFICIAL FRENCH TRANSLATION
Patch version: 1.0-BETA — 31 October 2026

REQUIREMENTS
You must own Lunacid. Supports the verified Windows 2.2.0 original files only.
The installer checks exact SHA-256 hashes, not just a displayed version number.
Uses Windows PowerShell 5.1 and .NET supplied with Windows. No Python, Node.js,
mod loader, external binary, or additional download is required.

INSTALLATION
1. Close Lunacid.
2. In Steam, right-click Lunacid > Manage > Browse local files.
3. Extract the ENTIRE ZIP there. Installer-FR.bat and Patch-FR must be beside
   LUNACID.exe. Do not run the BAT from inside the archive.
4. Double-click Installer-FR.bat and wait for the SUCCES message.
5. Launch the game normally. Keep English selected in the language settings.

Both English files are backed up before replacement. French files are rebuilt
locally and verified against the tested translation. Only these files change:
  LUNACID_Data\resources.assets
  LUNACID_Data\Resources\TXT\ENG\COMM.txt
Keep the Lunacid-FR-Sauvegardes folder. Progress/save-game data is not accessed.

RESTORE ENGLISH
Close the game, then double-click Restaurer-Anglais.bat. The saved originals
and current files are verified before replacement. Backups remain available.
You can reinstall French afterwards with Installer-FR.bat.

TROUBLESHOOTING
An incompatible version, another mod changing the same files, a corrupted patch,
an invalid backup, or a running game causes installation to stop with an error.
Restoration refuses files changed since installation. Restore compatible original
files first; Steam verification retrieves the currently available game version,
which may no longer be 2.2.0 after a future update.
An existing installation made with this kit is detected without overwriting it.
A manually translated copy without this kit's English backups must first be
returned to compatible originals. This delta kit does not contain those originals.
Ensure the game directory is writable. Managed Windows systems that prohibit
scripts may block the installer. Do not edit the expected hashes to bypass checks.

COVERAGE AND BETA STATUS
1,813 translated I2 keys, 214 intentionally unchanged values, and 34 translated
COMM.txt lines. Covers menus, UI, weapons, items, spells, dialogue, books,
cutscenes, lore, and endings handled by these resources.
Proper names, puzzle clues, and technical elements are preserved. The author's
pronoun system is preserved; some pronouns intentionally remain in English.
The hard-coded Health: label may also remain English. Notes is French as well.

The translation works in game, including accents, but has NOT undergone
exhaustive human proofreading. French text and scripts were produced with help
from OpenAI Codex; the project owner tested integration in game. Please report
issues with context and, when possible, a screenshot. This is an unofficial
fan project, not an official or endorsed localization.

DISTRIBUTION
The archive contains two binary deltas, readable installer scripts and docs.
It includes no game executable, DLL, complete resources.assets or complete
COMM.txt. Required original data is read from your compatible game installation.
A delta format does not automatically grant distribution rights. The script
license does not cover Lunacid's writing or assets. See the credits/license files.
