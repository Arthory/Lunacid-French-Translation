@echo off
setlocal DisableDelayedExpansion
title Lunacid - Installation francaise
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Patch-FR\Lunacid-FR.ps1" -Mode Install -GameRoot "%~dp0."
set "LUNACID_FR_RESULT=%ERRORLEVEL%"
if not "%LUNACID_FR_NO_PAUSE%"=="1" pause
exit /b %LUNACID_FR_RESULT%
